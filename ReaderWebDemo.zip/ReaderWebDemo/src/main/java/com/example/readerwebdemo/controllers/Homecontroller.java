package com.example.readerwebdemo.controllers;

import com.example.readerwebdemo.model.Xmlrdr;
import com.google.common.io.Files;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;


import java.io.File;

import java.io.IOException;

@Controller
public class Homecontroller {
@Autowired
    Xmlrdr xmlService;
@GetMapping("/")
    public String home(){
        return "Home";

    }


    @PostMapping ("/processFile")
    public String fileSubmit(Model model, @RequestParam("file") MultipartFile fileMulti) throws IOException {
    File file = new File("copy"+fileMulti.getOriginalFilename());
    file.createNewFile();
        FileUtils.openOutputStream(file);
        Files.write(fileMulti.getBytes(), file);
String xml = xmlService.xmlparse(file);

        model.addAttribute("fileResult", xml);
        return "Results";
    }

    @ResponseBody
    @GetMapping("/about")
    public String about(){
        return "about hi";

    }
}

